create
    definer = root@localhost procedure proc_1(IN my_year int, IN my_month int, OUT returnCode int)
    comment 'Отчёты о собеседованиях'
BEGIN
    declare done int default 0;
    declare my_date DATE;
    declare my_int_id INT;
    declare my_can_fio varchar(100);
    declare my_emp_fio varchar(100);
    declare my_job_t varchar(45);
    declare my_cand_id INT;
    declare cur cursor for
        select interview.Interview_ID as int_id,
			   interview_info.Candid_ID as can_id,
               candidate.Candid_FIO as can_fio,
               employee.Emp_FIO as emp_fio,
               vacancy.Job_title as job_t
        from interview
        join interview_info
			on interview_info.Inter_ID = interview.Interview_ID
		join employee 
			on interview_info.Empl_ID = employee.Employee_ID
		join candidate
			on interview_info.Candid_ID = candidate.Candidate_ID
		join vacancy
			on interview_info.Vacan_ID = vacancy.Vacancy_ID
        where year(interview.Date_of) = my_year
          and month(interview.Date_of) = my_month;
    declare continue handler for not found set done = 1;
    set returnCode = 0;
    set my_date = CAST(CONCAT(my_year, '-', my_month, '-', '01') AS DATE);
    if not exists(select * from report_1 where Inter_date = my_date) then
        open cur;
        while done = 0
            do
                fetch cur into my_int_id, my_cand_id, my_can_fio, my_emp_fio, my_job_t;
                if done = 0 then
                    insert into report_1(Inter_ID, Cand_ID, Candidate_FIO, Employee_FIO, Job_title, Inter_date)
                    values (my_int_id, my_cand_id, my_can_fio, my_emp_fio, my_job_t, my_date);
                end if;
                if not exists(select * from interview where Date_of = my_date) then
					set returnCode = -1;
                end if;
            end while;
        close cur;
	else
		set returnCode = -2;
    end if;

	select * from report_1 where Inter_date = my_date;
END;

